package dev.vinprime.vintpchest;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Properties;
import net.fabricmc.loader.api.FabricLoader;

final class VinTPChestConfig {
    private static final Path FILE = FabricLoader.getInstance().getConfigDir().resolve("vintpchest.properties");
    private static final Properties PROPERTIES = new Properties();

    static {
        PROPERTIES.setProperty("searchCommand", "chesttp {query}");
        PROPERTIES.setProperty("refreshCommand", "chesttp list");
        load();
    }

    private VinTPChestConfig() {}

    static String searchCommand(String query) {
        return PROPERTIES.getProperty("searchCommand", "chesttp {query}").replace("{query}", query);
    }

    static String refreshCommand() {
        return PROPERTIES.getProperty("refreshCommand", "chesttp list");
    }

    private static void load() {
        try {
            if (Files.exists(FILE)) {
                try (InputStream in = Files.newInputStream(FILE)) {
                    PROPERTIES.load(in);
                }
            } else {
                save();
            }
        } catch (IOException ignored) {
            // Defaults remain usable; user can create the config file manually.
        }
    }

    private static void save() throws IOException {
        Files.createDirectories(FILE.getParent());
        try (OutputStream out = Files.newOutputStream(FILE)) {
            PROPERTIES.store(out, "VinTPChest command templates. Replace these with commands your server actually supports.");
        }
    }
}
