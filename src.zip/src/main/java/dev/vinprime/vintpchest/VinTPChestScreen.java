package dev.vinprime.vintpchest;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.text.Text;

public final class VinTPChestScreen extends Screen {
    private TextFieldWidget searchField;
    private String status = "Use only commands supported by this server.";

    public VinTPChestScreen() {
        super(Text.literal("VinTPChest"));
    }

    @Override
    protected void init() {
        int centerX = this.width / 2;
        int panelWidth = Math.min(340, this.width - 24);
        int left = centerX - panelWidth / 2;
        int top = Math.max(28, this.height / 2 - 92);

        searchField = new TextFieldWidget(
                this.textRenderer, left + 16, top + 62, panelWidth - 32, 20,
                Text.literal("Search chest")
        );
        searchField.setMaxLength(64);
        searchField.setPlaceholder(Text.literal("Chest / shulker name or ID..."));
        addDrawableChild(searchField);

        addDrawableChild(ButtonWidget.builder(Text.literal("SEARCH / TP"), button -> search())
                .dimensions(left + 16, top + 94, (panelWidth - 40) / 2, 20).build());

        addDrawableChild(ButtonWidget.builder(Text.literal("REFRESH"), button -> refresh())
                .dimensions(left + 24 + (panelWidth - 40) / 2, top + 94, (panelWidth - 40) / 2, 20).build());

        addDrawableChild(ButtonWidget.builder(Text.literal("CLOSE"), button -> close())
                .dimensions(centerX - 45, top + 126, 90, 20).build());
        setInitialFocus(searchField);
    }

    private void search() {
        String query = searchField == null ? "" : searchField.getText().trim();
        if (query.isEmpty()) {
            status = "Enter a chest name or ID first.";
            return;
        }
        VinTPChestClient.sendServerCommand(VinTPChestConfig.searchCommand(query));
        status = "Sent search command to server. Check server response.";
    }

    private void refresh() {
        VinTPChestClient.sendServerCommand(VinTPChestConfig.refreshCommand());
        status = "Sent refresh command to server. Check server response.";
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        renderBackground(context, mouseX, mouseY, delta);
        int panelWidth = Math.min(340, this.width - 24);
        int left = this.width / 2 - panelWidth / 2;
        int top = Math.max(28, this.height / 2 - 92);

        // Black panel with red border/accent.
        context.fill(left, top, left + panelWidth, top + 158, 0xF0181818);
        context.fill(left, top, left + panelWidth, top + 3, 0xFFFF3038);
        context.fill(left, top, left + 2, top + 158, 0xFFFF3038);
        context.fill(left + panelWidth - 2, top, left + panelWidth, top + 158, 0xFFFF3038);
        context.fill(left, top + 156, left + panelWidth, top + 158, 0xFFFF3038);

        context.drawCenteredTextWithShadow(textRenderer, Text.literal("VIN").styled(s -> s.withColor(0xFFFF3038)), this.width / 2 - 30, top + 14, 0xFFFF3038);
        context.drawCenteredTextWithShadow(textRenderer, Text.literal("TP CHEST").styled(s -> s.withBold(true)), this.width / 2 + 30, top + 14, 0xFFFFFFFF);
        context.drawCenteredTextWithShadow(textRenderer, Text.literal("SERVER-SUPPORTED TELEPORT"), this.width / 2, top + 38, 0xFFB8B8B8);
        context.drawCenteredTextWithShadow(textRenderer, Text.literal(status), this.width / 2, top + 150, 0xFFFF7777);

        super.render(context, mouseX, mouseY, delta);
    }

    @Override
    public boolean shouldPause() {
        return false;
    }
}
